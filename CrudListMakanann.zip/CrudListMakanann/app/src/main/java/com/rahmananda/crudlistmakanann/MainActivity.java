package com.rahmananda.crudlistmakanann;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rahmananda.crudlistmakanann.model.DataItem;
import com.rahmananda.crudlistmakanann.model.Response;
import com.rahmananda.crudlistmakanann.network.ApiClient;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.rahmananda.crudlistmakanann.network.ApiClient;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.rv_makanan)
    RecyclerView rvMakanan;
    @BindView(R.id.fab)
    FloatingActionButton fab;

    private MakananAdapter makananAdapter;
    private List<DataItem> dataItems1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//preferences
//        String email = preferences.getEmail(this);
//        String password = preferences.getPassword(this);
//
//        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)){
//            startActivity(new Intent(MainActivity.this,LoginActivity.class));
//            finish();
//        }


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                Intent intent = new Intent(MainActivity.this, InsertActivity.class);
                startActivity(intent);
            }
        });

        rvMakanan.setLayoutManager(new LinearLayoutManager(this));
        rvMakanan.setHasFixedSize(true);

        ApiClient.service.getAllMakanan().enqueue(new Callback<Response>() {
            @Override
            public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                dataItems1 = response.body().getData();

                makananAdapter = new MakananAdapter(dataItems1, MainActivity.this);
                rvMakanan.setAdapter(makananAdapter);
            }

            @Override
            public void onFailure(Call<Response> call, Throwable t) {

            }
        });

        reloadData();
    }
    //buat realtime data
    public void reloadData(){

        ApiClient.service.getAllMakanan().enqueue(new Callback<Response>() {
            @Override
            public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                if (response.isSuccessful()) {
                    List<DataItem> dataItems = response.body().getData();
                    MakananAdapter adapterMakanan = new MakananAdapter(dataItems, MainActivity.this);
                    rvMakanan.setAdapter(adapterMakanan);

                }

            }

            @Override
            public void onFailure(Call<Response> call, Throwable t) {
            }

            });
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.i_logout) {
//            preferences.actionLogoutPreferences(this);
//            startActivity(new Intent(MainActivity.this, LoginActivity.class));
//            finish();
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
}

