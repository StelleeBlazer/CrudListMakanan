package com.rahmananda.crudlistmakanann;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.rahmananda.crudlistmakanann.model.DataItem;
import com.rahmananda.crudlistmakanann.model.Response;
import com.rahmananda.crudlistmakanann.network.ApiClient;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;

public class UpdateDeleteActivity extends AppCompatActivity {

    @BindView(R.id.edt_update_nama)
    EditText edtUpdateNama;
    @BindView(R.id.edt_update_harga)
    EditText edtUpdateHarga;
    @BindView(R.id.edt_update_gambar)
    EditText edtUpdateGambar;
    @BindView(R.id.btn_update)
    Button btnUpdate;
    @BindView(R.id.btn_delete)
    Button btnDelete;

    DataItem dataItemMakanan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);
        ButterKnife.bind(this);

        dataItemMakanan = getIntent().getParcelableExtra("UPDATE");
        if (dataItemMakanan !=null){
            edtUpdateNama.setText(dataItemMakanan.getMenuNama());
            edtUpdateHarga.setText(dataItemMakanan.getMenuHarga());
            edtUpdateGambar.setText(dataItemMakanan.getMenuGambar());
        }

    }

    @OnClick({R.id.btn_update, R.id.btn_delete})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_update:

                String nama  = edtUpdateNama.getText().toString();
                String harga  = edtUpdateHarga.getText().toString();
                String gambar  = edtUpdateGambar.getText().toString();

                if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(harga) || TextUtils.isEmpty(gambar)){
                    Toast.makeText(this, "Update Berhasil!", Toast.LENGTH_SHORT).show();
                }else {
                    actionUpdate(dataItemMakanan.getMenuId(),nama,harga,gambar);
                }

                break;
            case R.id.btn_delete:

                String id  = btnDelete.getText().toString();
                Toast.makeText(this, "Delete Berhasil!", Toast.LENGTH_SHORT).show();

                new AlertDialog.Builder(this)
                        .setTitle("KONFIRMASI")
                        .setMessage("Apakah Anda Yakin Menghapus Data?")
                        .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                actionDelete(dataItemMakanan.getMenuId());

                            }
                        }).setNeutralButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();



                break;
        }
    }

    public void actionUpdate(String id, String nama, String harga, String gambar){
        ApiClient.service.updateMakanan(id, nama, harga, gambar).enqueue(new Callback<Response>() {
            @Override
            public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                if (response.isSuccessful()){
                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status){
                        Toast.makeText(UpdateDeleteActivity.this, "Update Berhasil!", Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(UpdateDeleteActivity.this, "Update Tidak Berhasil...", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<Response> call, Throwable t) {

            }
        });
    }

    public void actionDelete(String id){
        ApiClient.service.deleteMakanan(id).enqueue(new Callback<Response>() {
            @Override
            public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                if (response.isSuccessful()){
                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status){
                        Toast.makeText(UpdateDeleteActivity.this, "Delete Berhasil!", Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(UpdateDeleteActivity.this, "Delete Tidak Berhasil...", Toast.LENGTH_SHORT).show();

                    }
                }
            }

            @Override
            public void onFailure(Call<Response> call, Throwable t) {

            }
        });
    }

}
