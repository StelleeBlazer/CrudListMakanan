package com.rahmananda.crudlistmakanann;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.rahmananda.crudlistmakanann.model.login.Data;
import com.rahmananda.crudlistmakanann.model.login.ResponseLogin;
import com.rahmananda.crudlistmakanann.network.ApiClient;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.edt_username)
    EditText edtUsername;
    @BindView(R.id.edt_password)
    EditText edtPassword;
    @BindView(R.id.btn_login)
    Button btnLogin;
    @BindView(R.id.tv_register)
    TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.btn_login, R.id.tv_register})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_login:

                String email = edtUsername.getText().toString();
                String password = edtPassword.getText().toString();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)){
                    Toast.makeText(this, "Inputan Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                }else {
                    actionLogin(email,password);
                }

                break;
            case R.id.tv_register:

                Intent intentRegister = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intentRegister);

                break;

        }

    }

    public void actionLogin(String email, String password) {
        ApiClient.service.loginMakanan(email, password).enqueue(new Callback<ResponseLogin>() {
            @Override
            public void onResponse(Call<ResponseLogin> call, Response<ResponseLogin> response) {
                if (response.isSuccessful()){
                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status){
                        Data data = response.body().getData();


                        String email = data.getUserEmail();
                        String password = data.getUserPassword();

                        preferences.actionLoginPreferences(LoginActivity.this, email,password);
                        Toast.makeText(LoginActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    }else {
                        Toast.makeText(LoginActivity.this, pesan, Toast.LENGTH_SHORT).show();

                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseLogin> call, Throwable t) {

            }
        });
    }
}
