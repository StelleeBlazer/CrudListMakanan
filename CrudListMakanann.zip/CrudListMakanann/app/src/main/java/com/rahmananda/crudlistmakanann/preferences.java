package com.rahmananda.crudlistmakanann;

import android.content.Context;
import android.content.SharedPreferences;

public class preferences {

    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;

    private static String KEY_EMAIL = "EMAIL";
    private static String KEY_PASSWORD = "PASSWORD";
    private static String KEY_LOGIN = "LOGIN";

    public static void actionLoginPreferences(Context context, String email, String password){
        sharedPreferences = context.getSharedPreferences(KEY_LOGIN, context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        editor.putString(KEY_EMAIL,email);
        editor.putString(KEY_PASSWORD,password);
        editor.apply();
    }

    public static String getEmail(Context context){
        sharedPreferences = context.getSharedPreferences(KEY_LOGIN,Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_EMAIL,null);
    }

    public static String getPassword(Context context){
        sharedPreferences = context.getSharedPreferences(KEY_LOGIN,Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_PASSWORD,null);
    }

    public static void actionLogoutPreferences(Context context){
        sharedPreferences = context.getSharedPreferences(KEY_LOGIN, context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.clear().apply();
    }

}
