package com.rahmananda.crudlistmakanann;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.rahmananda.crudlistmakanann.model.Response;
import com.rahmananda.crudlistmakanann.network.ApiClient;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;

public class InsertActivity extends AppCompatActivity {

    @BindView(R.id.edt_nama_makanan)
    EditText edtNamaMakanan;
    @BindView(R.id.edt_harga)
    EditText edtHarga;
    @BindView(R.id.edt_gambar)
    EditText edtGambar;
    @BindView(R.id.btn_insert)
    Button btnInsert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.btn_insert)
    public void onViewClicked() {

        String nama = edtNamaMakanan.getText().toString();
        String harga = edtHarga.getText().toString();
        String gambar = edtGambar.getText().toString();

        if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(harga) || TextUtils.isEmpty(gambar)){
            Toast.makeText(this, "inputan Tidak Boleh kosong", Toast.LENGTH_SHORT).show();
        }else {
            ApiClient.service.insertMakanan(nama,harga,gambar).enqueue(new Callback<Response>() {
                @Override
                public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                    if (response.isSuccessful()){


                        String pesan = response.body().getPesan();
                        boolean sukses = response.body().isSukses();

                        if (sukses){
                            Toast.makeText(InsertActivity.this,pesan, Toast.LENGTH_SHORT).show();
                            finish();
                        }else {
                            Toast.makeText(InsertActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<Response> call, Throwable t) {

                }
            });
        }
    }
}
